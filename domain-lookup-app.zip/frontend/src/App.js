import React, { useState } from "react";

function App() {
  const [domain, setDomain] = useState("");
  const [data, setData] = useState(null);

  const fetchWhois = async () => {
    const res = await fetch(`/api/whois?domain=${encodeURIComponent(domain)}`);
    const json = await res.json();
    setData(json);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Domain Lookup Tool</h1>
      <input value={domain} onChange={e => setDomain(e.target.value)} placeholder="Enter domain..." />
      <button onClick={fetchWhois}>Lookup</button>
      {data && <pre>{JSON.stringify(data, null, 2)}</pre>}
    </div>
  );
}

export default App;